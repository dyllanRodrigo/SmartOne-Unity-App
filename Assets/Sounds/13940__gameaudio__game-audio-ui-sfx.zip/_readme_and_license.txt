Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by the following user:
 - GameAudio ( https://www.freesound.org/people/GameAudio/ )

You can find this pack online at: https://www.freesound.org/people/GameAudio/packs/13940/

License details
---------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 220212__gameaudio__ping-bing.wav
    * url: https://www.freesound.org/s/220212/
    * license: Creative Commons 0
  * 220211__gameaudio__button-casual-event.wav
    * url: https://www.freesound.org/s/220211/
    * license: Creative Commons 0
  * 220210__gameaudio__deny-feel.wav
    * url: https://www.freesound.org/s/220210/
    * license: Creative Commons 0
  * 220209__gameaudio__teleport-space-morph.wav
    * url: https://www.freesound.org/s/220209/
    * license: Creative Commons 0
  * 220208__gameaudio__click-pop-two-part.wav
    * url: https://www.freesound.org/s/220208/
    * license: Creative Commons 0
  * 220207__gameaudio__boot-sound.wav
    * url: https://www.freesound.org/s/220207/
    * license: Creative Commons 0
  * 220206__gameaudio__beep-space-button.wav
    * url: https://www.freesound.org/s/220206/
    * license: Creative Commons 0
  * 220205__gameaudio__teleport-darker.wav
    * url: https://www.freesound.org/s/220205/
    * license: Creative Commons 0
  * 220204__gameaudio__ping-sound-ricochet.wav
    * url: https://www.freesound.org/s/220204/
    * license: Creative Commons 0
  * 220203__gameaudio__casual-death-loose.wav
    * url: https://www.freesound.org/s/220203/
    * license: Creative Commons 0
  * 220202__gameaudio__teleport-casual.wav
    * url: https://www.freesound.org/s/220202/
    * license: Creative Commons 0
  * 220201__gameaudio__spacey-ricochet.wav
    * url: https://www.freesound.org/s/220201/
    * license: Creative Commons 0
  * 220200__gameaudio__basic-click-wooden.wav
    * url: https://www.freesound.org/s/220200/
    * license: Creative Commons 0
  * 220199__gameaudio__click-higher.wav
    * url: https://www.freesound.org/s/220199/
    * license: Creative Commons 0
  * 220198__gameaudio__click-with-two-parts.wav
    * url: https://www.freesound.org/s/220198/
    * license: Creative Commons 0
  * 220197__gameaudio__click-basic.wav
    * url: https://www.freesound.org/s/220197/
    * license: Creative Commons 0
  * 220196__gameaudio__click-wooden-2.wav
    * url: https://www.freesound.org/s/220196/
    * license: Creative Commons 0
  * 220195__gameaudio__click-wooden-1.wav
    * url: https://www.freesound.org/s/220195/
    * license: Creative Commons 0
  * 220194__gameaudio__click-heavy.wav
    * url: https://www.freesound.org/s/220194/
    * license: Creative Commons 0
  * 220193__gameaudio__teleport-spacey.wav
    * url: https://www.freesound.org/s/220193/
    * license: Creative Commons 0
  * 220192__gameaudio__space-swoosh-darker.wav
    * url: https://www.freesound.org/s/220192/
    * license: Creative Commons 0
  * 220191__gameaudio__space-swoosh-brighter.wav
    * url: https://www.freesound.org/s/220191/
    * license: Creative Commons 0
  * 220190__gameaudio__blip-pop.wav
    * url: https://www.freesound.org/s/220190/
    * license: Creative Commons 0
  * 220189__gameaudio__blip-squeak.wav
    * url: https://www.freesound.org/s/220189/
    * license: Creative Commons 0
  * 220188__gameaudio__deny-casual-2.wav
    * url: https://www.freesound.org/s/220188/
    * license: Creative Commons 0
  * 220187__gameaudio__deny-casual-1.wav
    * url: https://www.freesound.org/s/220187/
    * license: Creative Commons 0
  * 220185__gameaudio__space-drill.wav
    * url: https://www.freesound.org/s/220185/
    * license: Creative Commons 0
  * 220184__gameaudio__win-spacey.wav
    * url: https://www.freesound.org/s/220184/
    * license: Creative Commons 0
  * 220183__gameaudio__click-casual.wav
    * url: https://www.freesound.org/s/220183/
    * license: Creative Commons 0
  * 220182__gameaudio__computer-beep-2.wav
    * url: https://www.freesound.org/s/220182/
    * license: Creative Commons 0
  * 220181__gameaudio__computer-beep-1.wav
    * url: https://www.freesound.org/s/220181/
    * license: Creative Commons 0
  * 220180__gameaudio__click-pop.wav
    * url: https://www.freesound.org/s/220180/
    * license: Creative Commons 0
  * 220179__gameaudio__click-metal-ting.wav
    * url: https://www.freesound.org/s/220179/
    * license: Creative Commons 0
  * 220178__gameaudio__click.wav
    * url: https://www.freesound.org/s/220178/
    * license: Creative Commons 0
  * 220177__gameaudio__quick-ui-or-event-deep.wav
    * url: https://www.freesound.org/s/220177/
    * license: Creative Commons 0
  * 220176__gameaudio__confirm-click-spacey.wav
    * url: https://www.freesound.org/s/220176/
    * license: Creative Commons 0
  * 220175__gameaudio__pop-click.wav
    * url: https://www.freesound.org/s/220175/
    * license: Creative Commons 0
  * 220174__gameaudio__spacey-loose.wav
    * url: https://www.freesound.org/s/220174/
    * license: Creative Commons 0
  * 220173__gameaudio__power-up.wav
    * url: https://www.freesound.org/s/220173/
    * license: Creative Commons 0
  * 220172__gameaudio__flourish-spacey-2.wav
    * url: https://www.freesound.org/s/220172/
    * license: Creative Commons 0
  * 220171__gameaudio__flourish-spacey-1.wav
    * url: https://www.freesound.org/s/220171/
    * license: Creative Commons 0
  * 220170__gameaudio__spacey-smooth-cricket-click.wav
    * url: https://www.freesound.org/s/220170/
    * license: Creative Commons 0
  * 220169__gameaudio__spacey-cricket-click.wav
    * url: https://www.freesound.org/s/220169/
    * license: Creative Commons 0
  * 220168__gameaudio__button-spacey-confirm.wav
    * url: https://www.freesound.org/s/220168/
    * license: Creative Commons 0
  * 220167__gameaudio__button-deny-spacey.wav
    * url: https://www.freesound.org/s/220167/
    * license: Creative Commons 0
  * 220166__gameaudio__button-confirm-spacey.wav
    * url: https://www.freesound.org/s/220166/
    * license: Creative Commons 0
  * 220165__gameaudio__spacey-teleport-rip-2.wav
    * url: https://www.freesound.org/s/220165/
    * license: Creative Commons 0
  * 220164__gameaudio__spacey-teleport-rip.wav
    * url: https://www.freesound.org/s/220164/
    * license: Creative Commons 0
  * 220163__gameaudio__teleport-slurp.wav
    * url: https://www.freesound.org/s/220163/
    * license: Creative Commons 0
  * 220162__gameaudio__teleport-high.wav
    * url: https://www.freesound.org/s/220162/
    * license: Creative Commons 0
  * 220161__gameaudio__teleport-morphy.wav
    * url: https://www.freesound.org/s/220161/
    * license: Creative Commons 0
  * 220160__gameaudio__teleport-staticky.wav
    * url: https://www.freesound.org/s/220160/
    * license: Creative Commons 0
  * 220159__gameaudio__spacey-drill-quick.wav
    * url: https://www.freesound.org/s/220159/
    * license: Creative Commons 0
  * 220158__gameaudio__spacey-quick-2.wav
    * url: https://www.freesound.org/s/220158/
    * license: Creative Commons 0
  * 220157__gameaudio__spacey-quick-1.wav
    * url: https://www.freesound.org/s/220157/
    * license: Creative Commons 0
  * 220156__gameaudio__rollover-low.wav
    * url: https://www.freesound.org/s/220156/
    * license: Creative Commons 0


